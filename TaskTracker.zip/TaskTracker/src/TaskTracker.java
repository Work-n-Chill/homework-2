import java.io.*;
import java.util.*;
import java.io.FileReader;


public class TaskTracker {
    public static void main(String[] args) {
        String usersPath = "src/users.csv";
        String tasksPath = "src/tasks.csv";
        List<User> users = loadUsers(usersPath);
        List<Task> tasks = loadTasks(tasksPath);

        for (Task task: tasks){
            for (User user: users){
                if (task.getUserId() == user.getId()){
                    user.addTask(task);
                }
            }
        }

        Map<User, List<Task>> data = new HashMap<>();
        for (User user: users) {
            data.put(user, user.getTasks());
        }

        System.out.println(data.entrySet());
        Scanner scanner = new Scanner(System.in);
        //System.out.println("Input user's name or task id");
        // определить что имеем на вход (вывод задач по ид юзера, фильтр, смена статуса)
        while (scanner.hasNext()){
            String line = scanner.nextLine();
            String[] array = line.split(", ");
            if (array.length <2){
                for(User user: data.keySet()){
                    if (user.getName().equals(line)){
                        System.out.println(data.get(user));
                    }
                }
            }
            else if(array[1].equals("f")) {
                for(User user: data.keySet()){
                    if (user.getName().equals(line)){
                        Comparator<Task> comparator = Comparator.comparing(task -> task.getStatus());
                        System.out.println(user.getTasks().sort(comparator));
                    }
                }
            }
            else if(array[1].equals("новая")|| array[1].equals("в работе")|| array[1].equals("готово")){
                int taskId = Integer.parseInt(array[0]);
                int userId = Integer.MAX_VALUE;
                for (Task task:tasks){
                    if (task.getTaskId() == taskId){
                        userId = task.getUserId();
                    }
                }
                for(User user: data.keySet()){
                    if (user.getId() == userId){
                        for(Task task: user.getTasks()){
                            task.setStatus(array[1]);
                        }
                    }
                }

            }
        }

    }

    private static List<User> loadUsers(String path) {
        List<User> users = new ArrayList<>();
        String line = "";
        try {
            BufferedReader csvReader = new BufferedReader (new FileReader(path));
            while ((line = csvReader.readLine()) != null){
                String[] data = line.split(",");
                users.add(new User(Integer.parseInt(data[0]), data[1]));
            }
            csvReader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return users;
    }

    private static List<Task> loadTasks(String path) {
        List<Task> tasks = new ArrayList<>();
        String line = "";
        try {
            BufferedReader csvReader = new BufferedReader (new FileReader(path));
            while ((line = csvReader.readLine()) != null){
                String[] data = line.split(", ");
                tasks.add(new Task(Integer.parseInt(data[0]), data[1], data[2], Integer.parseInt(data[3]), data[4]));
            }
            csvReader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tasks;
    }


}
