import java.util.Date;

public class Task {
    private int taskId;
    private String header;
    private String description;
    private int userId;
    private String deadline;
    private String status;
    //final String NEW = "новая";
    //final String INWORK = "в работе";
    //final String DONE = "готово";

    public Task(int taskId, String header, String description,int userId, String deadline) {
        this.taskId = taskId;
        this.header = header;
        this.userId = userId;
        this.description = description;
        this.deadline = deadline;
        this.status = "новая";
    }

    public int getTaskId() {
        return taskId;
    }

    public String getHeader() {
        return header;
    }

    public String getDescription() {
        return description;
    }

    public String  getDeadline() {
        return deadline;
    }

    public String getStatus() {
        return status;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDeadline(String  deadline) {
        this.deadline = deadline;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

}
